from pymol.cgo import *
from pymol import cmd
pocket = [
    COLOR, 0.053, 0.492, 0.026,
    SPHERE, 24.943, 19.939, 32.023, 1.807,
    COLOR, 0.916, 0.931, 0.770,
    SPHERE, 21.610, 23.883, 26.291, 1.603,
    COLOR, 0.833, 0.151, 0.269,
    SPHERE, 21.257, 20.084, 31.407, 1.414,
    COLOR, 0.092, 0.247, 0.665,
    SPHERE, 17.372, 13.304, 28.240, 1.380,
    COLOR, 0.387, 0.018, 0.347,
    SPHERE, 22.150, 15.340, 33.845, 1.349,
    COLOR, 0.415, 0.571, 0.031,
    SPHERE, 15.310, 17.791, 29.593, 1.344,
    COLOR, 0.201, 0.475, 0.409,
    SPHERE, 25.816, 14.964, 34.806, 1.225,
    COLOR, 0.028, 0.086, 0.185,
    SPHERE, 28.738, 9.615, 34.975, 1.000,
]
cmd.load('data/pdb/1qrd.pdb.gz', '1qrd')
cmd.load_cgo(pocket, 'pocket')
cmd.hide('everything', selection='1qrd')
cmd.show('cartoon', selection='1qrd')
cmd.show('sticks', selection='/1qrd//A/FAD`274')
cmd.bg_color('white')
cmd.ray()
